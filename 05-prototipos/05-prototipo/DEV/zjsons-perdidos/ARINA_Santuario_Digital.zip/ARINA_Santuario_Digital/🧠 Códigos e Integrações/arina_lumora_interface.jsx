// Interface react da integração Lumora -> ARINA
// Inclui prompts vibracionais e integração GPT