# Novo Manual da Equipe Próxima: Guia Estratégico para Operações e Alinhamento

Created time: 7 de julho de 2025 16:37