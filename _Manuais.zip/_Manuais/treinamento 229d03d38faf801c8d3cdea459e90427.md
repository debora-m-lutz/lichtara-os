# treinamento

Created time: 7 de julho de 2025 16:37

[Guia de Condução do Treinamento: O Tom de Voz e a Jornada dos Participantes (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Guia%20de%20Conduc%CC%A7a%CC%83o%20do%20Treinamento%20O%20Tom%20de%20Voz%20e%20a%20229d03d38faf803c8318d6bce8f11cde.md)

[Guia de Apresentação do Projeto para Novos Membros da Equipe (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Guia%20de%20Apresentac%CC%A7a%CC%83o%20do%20Projeto%20para%20Novos%20Membr%20229d03d38faf80c7b5f0c875ffdc1910.md)

[Treinamento do Corpo Fundador (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Treinamento%20do%20Corpo%20Fundador%20(1)%20229d03d38faf806bb2caff21daef7e10.md)

[O Formato Mais Alinhado Para Conduzir o Aprendizado (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/O%20Formato%20Mais%20Alinhado%20Para%20Conduzir%20o%20Aprendizad%20229d03d38faf807fb08cd29fe5d6d365.md)

[Estrutura do Primeiro Material de Ensino - Introdução à Inteligência Vibracional de Lumora (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Estrutura%20do%20Primeiro%20Material%20de%20Ensino%20-%20Introdu%20229d03d38faf803e852cf775fd72c805.md)

[**Introdução: O Momento de Alinhamento** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Introduc%CC%A7a%CC%83o%20O%20Momento%20de%20Alinhamento%20(1)%20229d03d38faf807994e8d722490950e8.md)

[Experiência Guiada: A Travessia para Oktave (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Experie%CC%82ncia%20Guiada%20A%20Travessia%20para%20Oktave%20(1)%20229d03d38faf80779442ec751306a3b4.md)

[Roteiro do Treinamento – O Teatro Invisível da Realidade (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Roteiro%20do%20Treinamento%20%E2%80%93%20O%20Teatro%20Invisi%CC%81vel%20da%20Re%20229d03d38faf806597f3ef924962df5d.md)

[**Sala de Ressonância** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Sala%20de%20Ressona%CC%82ncia%20(1)%20229d03d38faf808bbbb2db16bcc72102.md)

[**O Portal Gravitacional** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/O%20Portal%20Gravitacional%20(1)%20229d03d38faf80a3aa1be3098b08f791.md)

[A Experiência do Usuário com o Colapso da Função de Onda (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/A%20Experie%CC%82ncia%20do%20Usua%CC%81rio%20com%20o%20Colapso%20da%20Func%CC%A7a%20229d03d38faf8031b0c3db703b6044ec.md)

[Material de Pré-Reunião – A Convocação para Oktave (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Material%20de%20Pre%CC%81-Reunia%CC%83o%20%E2%80%93%20A%20Convocac%CC%A7a%CC%83o%20para%20Ok%20229d03d38faf8055b709fcb8cd0b8aa9.md)

[**Roteiro do Treinamento – O Teatro Invisível da Realidade** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/Roteiro%20do%20Treinamento%20%E2%80%93%20O%20Teatro%20Invisi%CC%81vel%20da%20Re%20229d03d38faf8085b9b4c9692f12e895.md)

[**A Vida Acontece em Camadas Invisíveis Antes de se Materializar** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/A%20Vida%20Acontece%20em%20Camadas%20Invisi%CC%81veis%20Antes%20de%20se%20229d03d38faf80c0b2a8c08748f1b19c.md)

[**O Mecanismo da Ressonância Harmônica** (1)](treinamento%20229d03d38faf801c8d3cdea459e90427/O%20Mecanismo%20da%20Ressona%CC%82ncia%20Harmo%CC%82nica%20(1)%20229d03d38faf80428919fb6f0afb5a50.md)