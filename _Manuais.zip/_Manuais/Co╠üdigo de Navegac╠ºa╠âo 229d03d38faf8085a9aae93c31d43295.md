# Código de Navegação

Created time: 7 de julho de 2025 16:37

[Dossiê Código de Navegação](Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8085a9aae93c31d43295/Dossie%CC%82%20Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf80e8a416dae92e1b40ed.md)

[**Bem-vindo ao Código de Navegação**  ](Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8085a9aae93c31d43295/Bem-vindo%20ao%20Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8020862ee0838b1484b8.md)

[Metodologia do Código de Navegação](Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8085a9aae93c31d43295/Metodologia%20do%20Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8030be4bfe47432f6adc.md)

[**Metodologia Direto do Campo Quântico**](Co%CC%81digo%20de%20Navegac%CC%A7a%CC%83o%20229d03d38faf8085a9aae93c31d43295/Metodologia%20Direto%20do%20Campo%20Qua%CC%82ntico%20229d03d38faf8018adc8fc8c43d82e25.md)