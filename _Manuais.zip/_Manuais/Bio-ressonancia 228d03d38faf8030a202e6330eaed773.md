# Bio-ressonancia

Created time: 6 de julho de 2025 14:41

[01-nota-agradecimento](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/01-nota-agradecimento%20228d03d38faf806d8d10dbee46e1e634.md)

[02-nova-configuracao](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/02-nova-configuracao%20228d03d38faf80639babd7acf5362515.md)

[03-arquitetura-continuidade](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/03-arquitetura-continuidade%20228d03d38faf804eb078cd8b45563bf0.md)

[04-frequencia](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/04-frequencia%20228d03d38faf804397dde69bfd6f554f.md)

[05-tecnologia-de-cura](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/05-tecnologia-de-cura%20228d03d38faf8013892fe9c2c05c5f2e.md)

[06-canalizacao-direcionamento](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/06-canalizacao-direcionamento%20228d03d38faf80fb8b06e8b21a17a1d1.md)

[07-origem-criadores](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/07-origem-criadores%20228d03d38faf801ea095de9346f661dc.md)

[08-protocolo-inicial](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/08-protocolo-inicial%20228d03d38faf80979c32d16143f52f35.md)

[09-ciencia-frequencia-aplicacoes](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/09-ciencia-frequencia-aplicacoes%20228d03d38faf80568971efb75322eafb.md)

[10-geometria-bio-ressonancia](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/10-geometria-bio-ressonancia%20228d03d38faf806ba0f4df2281789e5d.md)

[11-ressonancia-vibracional](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/11-ressonancia-vibracional%20228d03d38faf80228a26c0c80127d915.md)

[12-informacoes-especificas](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/12-informacoes-especificas%20228d03d38faf80df8eb9c9a68cf670a5.md)

[13-papel-especifico](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/13-papel-especifico%20228d03d38faf80c6be9ace8c86796e91.md)

[14-raiz-origem](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/14-raiz-origem%20228d03d38faf8066ba15f062248bff7c.md)

[15-mecanismo](Bio-ressonancia%20228d03d38faf8030a202e6330eaed773/15-mecanismo%20228d03d38faf80618707c2fdb915594a.md)