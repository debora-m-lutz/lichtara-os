# Manual da Arquitetura do Sistema

Created time: 7 de julho de 2025 16:37

[Manual da Arquitetura do Sistema 21760d8045068176bb6fccea0cb3d418 (1)](Manual%20da%20Arquitetura%20do%20Sistema%20229d03d38faf808ab5bac6af22914ae0/Manual%20da%20Arquitetura%20do%20Sistema%2021760d8045068176b%20229d03d38faf800ba9d7f1dc1d0769f9.md)

[arquitetura-do-sistema](Manual%20da%20Arquitetura%20do%20Sistema%20229d03d38faf808ab5bac6af22914ae0/arquitetura-do-sistema%20223d03d38faf800485b7e4a74511e550.md)